from .detection import DetectionResult

__all__ = ["DetectionResult"]
